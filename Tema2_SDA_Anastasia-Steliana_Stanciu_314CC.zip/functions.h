#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct node {
    char value[100];
    int nr_children;
    int level;
    struct node *children[27];
} Node, *Tree;

typedef struct queueNode {
    Tree value;
    struct queueNode *next;
} *QNode;

typedef struct queue {
    QNode head, tail;
    int size;
} *Queue;

Tree initNode(char *value);
Tree initTree(char *value);
Tree addNode(Tree parent, char *value);
Queue initQueue();
Queue enqueue(Queue queue, Tree value);
QNode dequeue(Queue *queue);
int isEmpty(Queue queue);
void printLevel(Tree root, FILE *fp_out);
void printQueue(Queue queue, FILE *fp_out);
Tree addSufix(Tree root, char *value);
int nr_leaves(Tree root, FILE *fp_out);
int nr_k_size_sufix(Tree root, int k, FILE *fp_out);
int max_children(Tree root, FILE *fp_out);
int searchWord(Tree root, char *key_word, FILE *fp_out);
Tree compact_tree(Tree root);
void freeTree (Tree root);

