#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"functions.h"

Queue initQueue() {
    Queue queue = (Queue)malloc(sizeof(struct queue));
    queue->head = NULL;
    queue->tail = NULL;
    queue->size = 0;
    return queue;
}

Queue enqueue(Queue queue, Tree value) {
    QNode new_node = (QNode)malloc(sizeof(struct queueNode));
    new_node->next = NULL;
    new_node->value = value;
    if (queue->size == 0) {
        queue->head = new_node;
        queue->tail = new_node;
    } else {
        queue->tail->next = new_node;
        queue->tail = new_node;
    }
    queue->size++;
    return queue;
}

QNode dequeue(Queue *queue) {
    if ((*queue)->size == 0) {
        return NULL;
    } else {
        QNode tmp;
        tmp = (*queue)->head;
        (*queue)->head = (*queue)->head->next;
        (*queue)->size--;
        return tmp;
    }
}

int isEmpty(Queue queue) {
    if (queue->size == 0) 
        return 1;
    return 0;
}

Tree initNode(char *value) {
    // initializez noul nod
    Tree new_node = (Tree)malloc(sizeof(Node));
    strncpy(new_node->value, value, 1);
    new_node->value[1] = '\0';
    int i;
    new_node->nr_children = 0;
    for (i = 0; i < 27; i++) {
        new_node->children[i] = NULL;
    }
    return new_node;
}

Tree initTree(char *value) {
    Tree root = initNode(value);
    root->nr_children = 0;
    root->level = -1;
    return root;
}

Tree addNode(Tree parent, char *value) {
    // initializez noul nod
    Tree new_node = initNode(value);
    // il leg la parinte in vectorul sau de fii
    int index_ch = *value - 'a' + 1;
    if (*value == '$') {
        index_ch = 0;
    }
    parent->children[index_ch] = new_node;
    new_node->level = parent->level + 1;
    parent->nr_children++;
    return parent;
}

void printLevel(Tree root, FILE *fp_out) {
    // indicator care ne spune dac aam trecut de radacina
    int ok = 0;
    Queue queue = initQueue();
    enqueue(queue, root);
    while (!isEmpty(queue)) {
        // evaluam cate elem sunt in coada; decrementam acest nr 
        // pana devine 0 => atunci ne aflam la finalul nivelului
        // si printam '\n'
        int length_newline = queue->size;
        while (length_newline) {
            // scoatem un elem din coada
            QNode current_node = dequeue(&queue);
            Tree current = current_node->value;
            if (ok == 1) {
                fprintf(fp_out, "%s ", current->value);
            }
            int i;
            // si ii adaugam toti copiii in coada
            for (i = 0; i < 27; i++) {
                if (current->children[i] != NULL)
                    queue = enqueue(queue, current->children[i]);
            }
            --length_newline;
            free(current_node);
        }
        if (ok == 1) {
            fprintf(fp_out, "\n");
        } else {
            ok = 1;
        }
    }
    free(queue);
}

void printQueue(Queue queue, FILE *fp_out) {
    int i;
    QNode iter = queue->head;
    for (i = 0; i < queue->size; i++) {
        fprintf(fp_out, "%c ", *(iter->value->value));
        iter = iter->next;
    }
}

// adauga in arbore UN sufix, NU toate sufixele cuvantului!
Tree addSufix(Tree root, char *value) {
    Tree iter = root;
    int i;
    // parcurgem cuvantul
    for (i = 0; i < strlen(value); i++) {
        // daca nodul curent are un fiu cu caracterul curent
        // la care ne aflam in parcurgerea cuvantului
        // trecem la acel nod 
        int index = value[i] - 'a' + 1;
        if (value[i] == '$') {
            index = 0;
        }
        if (iter->children[index] != NULL) {
            iter = iter->children[index];
        } else {
        // altfel, adaugam un nod nou
            iter = addNode(iter, value + i);
            int aux = value[i] - 'a' + 1;
            iter = iter->children[aux];
        }
    }
    return root;
}

int nr_leaves(Tree root, FILE *fp_out) {
    Queue queue = initQueue();
    int count = 0;
    enqueue(queue, root);
    while (!isEmpty(queue)) {
        QNode current_node = dequeue(&queue);
        Tree current = current_node->value;
        if (*(current->value) == '$') {
            count++;
        }
        int i;
        for (i = 0; i < 27; i++) {
            if (current->children[i] != NULL) {
                queue = enqueue(queue, current->children[i]);
            }
        }
        free(current_node);
    }
    free(queue);
    fprintf(fp_out, "%d\n", count);
    return count;
}

int nr_k_size_sufix(Tree root, int k, FILE *fp_out) {
    Queue queue = initQueue();
    enqueue(queue, root);
    int count = 0;
    while (!isEmpty(queue)) {
        QNode current_node = dequeue(&queue);
        Tree current = current_node->value;
        if (*(current->value) == '$' && current->level == k) {
            count++;
        }
        int i;
        for (i = 0; i < 27; i++) {
            if (current->children[i] != NULL) {
                queue = enqueue(queue, current->children[i]);
            }
        }
        free(current_node);
    }
    free(queue);
    fprintf(fp_out, "%d\n", count);
    return count;
}

int max_children(Tree root, FILE *fp_out) {
    Queue queue = initQueue();
    enqueue(queue, root);
    int max = 0;
    while (!isEmpty(queue)) {
        QNode current_node = dequeue(&queue);
        Tree current = current_node->value;
        if (current->nr_children > max) {
            max = current->nr_children;
        }
        int i;
        for (i = 0; i < 27; i++) {
            if (current->children[i] != NULL) {
                queue = enqueue(queue, current->children[i]);
            }
        }
        free(current_node);
    }
    free(queue);
    fprintf(fp_out, "%d\n", max);
    return max;
}

int searchWord(Tree root, char *key_word, FILE *fp_out) {
    // creez un iter cu care parcurg arborele pe
    // directai cuvantului dat
    Tree iter = root;
    // ok = var care indica daca cuvantul apartine arborelui
    int ok = 1, i;
    // parcurgem cuvantul prin arbore
    for (i = 0; i < strlen(key_word); i++) {
        int index = key_word[i] - 'a' + 1;
        if (key_word[i] == '$') {
            index = 0;
        }
        // daca nodul actual are un copil cu caracterul
        // curent din cuvant => ne mutam in el
        if (iter->children[index] != NULL) {
            iter = iter->children[index];
        } else {
            // altfel ok = 0 si iesim din for-ul de cautare
            ok = 0;
            break;
        }
    }
    fprintf(fp_out, "%d\n", ok);
    return ok;
}

Tree compact_tree(Tree root) {
    Queue queue = initQueue();
    queue = enqueue(queue, root);
    while (!isEmpty(queue)) {
        QNode current_node = dequeue(&queue);
        Tree current = current_node->value;
        // daca nodul curent are 1 copil => il putem face compact (parinte + copil)
        if (current->nr_children == 1) {
            // cautam nodul copil
            int i;
            for (i = 1; i < 27; i++) {
                // cand gasim unicul copil, concatenam continutul copilului
                // la continutul parintelui
                if(current->children[i] != NULL) {
                    strcat(current->value, current->children[i]->value);
                    // stergem copilul din lista de copii a parintelui
                    // il tinem minte temporar in tmp_child 
                    Tree tmp_child = current->children[i];
                    current->children[i] = NULL;
                    current->nr_children = 0;
                    // mutam copiii copilului la parinte
                    int j;
                    for (j = 0; j < 27; j++) {
                        if (tmp_child->children[j] != NULL) {
                            current->children[j] = tmp_child->children[j];
                            current->nr_children++;
                        }
                    }
                    //free(tmp_child);
                    queue = enqueue(queue, current);
                    break;
                }
            }
        }
        // ii adaugam toti copii in coada
        int i;
        for (i = 0; i < 27; i++) {
            if (current->children[i] != NULL) {
                queue = enqueue(queue, current->children[i]);
            }
        }
        free(current_node);
    }
    free(queue->head);
    free(queue);
    return root;
}

void freeTree (Tree root) {
    Queue queue = initQueue();
    queue = enqueue(queue, root);
    while (!isEmpty(queue)) {
        QNode current_node = dequeue(&queue);
        Tree current = current_node->value;
        int i;
        for (i = 0; i < 27; i++) {
            if (current->children[i] != NULL)
                queue = enqueue(queue, current->children[i]);
        }
        free(current);
        free(current_node);
    }
    free(queue);
}