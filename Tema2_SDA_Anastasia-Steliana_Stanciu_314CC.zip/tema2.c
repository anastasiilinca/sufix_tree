#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"functions.h"

int main(int argc, char *argv[]) {
    char cerinta[4], K[3], c_1[4] = "-c1", c_2[4] = "-c2";
    char c_3[4] = "-c3", c_4[4] = "-c4";
    int i;
    char in_file[50], out_file[50];
    strcpy(cerinta, argv[1]);
    // daca ne aflam la cerinta 2, avem de extras din argv
    // si parametrul K
    if (strcmp(cerinta, c_2) == 0) {
        strcpy(K, argv[2]);
        strcpy(in_file, argv[3]);
        strcpy(out_file, argv[4]);
    } else {
        strcpy(in_file, argv[2]);
        strcpy(out_file, argv[3]);
    }
    FILE *fp_in = fopen(in_file, "r");
    FILE *fp_out = fopen(out_file, "w");
    if (strcmp(cerinta, c_1) == 0) {
        // nr cuvinte de pus in arbore
        int N;
        fscanf(fp_in, "%d", &N);
        char key_word[100];
        //initializam arborele
        Tree root = initTree("*");
        // adaugam toate cuvintele in arbore
        for (i = 0; i < N; i++) {
            fscanf(fp_in, "%s", key_word);
            key_word[strlen(key_word) + 1] = '\0';
            key_word[strlen(key_word)] = '$';
            while (strlen(key_word) != 0) {
                root = addSufix(root, key_word);
                char *aux = (char *)malloc(sizeof(char) * strlen(key_word));
                strcpy(aux, key_word + 1);
                strcpy(key_word, aux);
                free(aux);
            }
        }
        printLevel(root, fp_out);
        freeTree(root);
    } else if (strcmp(cerinta, c_2) == 0) {
        // nr cuvinte de pus in arbore
        int N;
        fscanf(fp_in, "%d", &N);
        char key_word[100];
        //initializam arborele
        Tree root = initTree("*");
        // adaugam toate cuvintele in arbore
        for (i = 0; i < N; i++) {
            fscanf(fp_in, "%s", key_word);
            key_word[strlen(key_word) + 1] = '\0';
            key_word[strlen(key_word)] = '$';
            while (strlen(key_word) != 0) {
                root = addSufix(root, key_word);
                char *aux = (char *)malloc(sizeof(char) * strlen(key_word));
                strcpy(aux, key_word + 1);
                strcpy(key_word, aux);
                free(aux);
            }
        }
        // transform paramterul K din char in nr
        int k;
        k = K[0] - '0';
        nr_leaves(root, fp_out);
        nr_k_size_sufix(root, k, fp_out);
        max_children(root, fp_out);
        freeTree(root);
    } else if (strcmp(cerinta, c_3) == 0) {
        // nr cuvinte de pus in arbore
        int N, M;
        fscanf(fp_in, "%d%d", &N, &M);
        char key_word[100];
        //initializam arborele
        Tree root = initTree("*");
        // adaugam toate cuvintele in arbore
        for (i = 0; i < N; i++) {
            fscanf(fp_in, "%s", key_word);
            key_word[strlen(key_word) + 1] = '\0';
            key_word[strlen(key_word)] = '$';
            while (strlen(key_word) != 0) {
                root = addSufix(root, key_word);
                char *aux = (char *)malloc(sizeof(char) * strlen(key_word));
                strcpy(aux, key_word + 1);
                strcpy(key_word, aux);
                free(aux);
            }
        }
        for (i = 0; i < M; i++) {
            fscanf(fp_in, "%s", key_word);
            key_word[strlen(key_word) + 1] = '\0';
            key_word[strlen(key_word)] = '$';
            searchWord(root, key_word, fp_out);
        }
        freeTree(root);
    } else if (strcmp(cerinta, c_4) == 0) {
        // nr cuvinte de pus in arbore
        int N;
        fscanf(fp_in, "%d", &N);
        char key_word[100];
        //initializam arborele
        Tree root = initTree("*");
        // adaugam toate cuvintele in arbore
        for (i = 0; i < N; i++) {
            fscanf(fp_in, "%s", key_word);
            key_word[strlen(key_word) + 1] = '\0';
            key_word[strlen(key_word)] = '$';
            while (strlen(key_word) != 0) {
                root = addSufix(root, key_word);
                char *aux = (char *)malloc(sizeof(char) * strlen(key_word));
                strcpy(aux, key_word + 1);
                strcpy(key_word, aux);
                free(aux);
            }
        }
        root = compact_tree(root);
        printLevel(root, fp_out);
        freeTree(root);
    }
    fclose(fp_in);
    fclose(fp_out);
    return 0;
}