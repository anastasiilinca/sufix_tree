TEMA 2 SDA

    Aceasta tema a presupus implementarea unuiprogram care construieste arbori
de sufixe pornind de la o lista de cuvinte. Programul caculeaza si niste 
proprietati ale arborelui rezultat si, de asemenea, are o functionalitate
separata de tranformare a arboreului de sufixe in forma sa compacta.

    Diferitele functionalitati sunt accesate prin intermediul argumentelor
in linia de comanda (vom folosi cuvintele cheie: c1, c2, c3, c4), care vor
fi date ca parametrii la rulare alaturi de numele fisierelor de in si out.

Implementarea cerintelor a constat in:

FUNCTII ARBORE:
- initNode: initializeaza un nod din arbore cu valoarea data ca parametru
            si returneaza pointer catre el
- initTree: initializeaza un arbore, creand radacina
- addNode: adauga un nod in arbore (se foloseste de functia initNode)
- printLevel: afiseaza un arbore, parcurgandu-l pe nivel
- addSufix: adauga in arbore UN sufix, nu toate sufixele unui cuvant;
primeste ca parametru sirul de caractere constituind sufixul care trebuie
adaugat
- nr_leaves: returneaza numarul de frunze din arbore
- nr_k_size_sufix: returneaza numarul de sufixe cu 'k' caractere
- max_children: returneaza numarul maxim de copii directi pe care
ii are un nod din arbore
- searchWord: afla daca 1 cuvant dat ca parametru se afla in arbore sau nu
- compact_tree: transforma un arbore normal de sufixe in forma sa compacta
- freeTree: elibereaza memoria ocupata de un arbore

Pentru construirea, printarea si analizarea arborelui ne folosim de o 
parcurgere pe nivel care se implementeaza printr-o coada (se scoate 
un nod din coada, se prelucreaza si apoi se adauga in coada toti
copiii sai pentru prelucrare). In acest sens, s-au construit functiile:

FUNCTII COADA:
- initQueue: initializeaza coada
- enqueue: adaugarea unui element in coada
- dequeue: scoaterea unui element din coada
- isEmpty: verifica daca o coada este goala sau nu
- printQueue: afiseaza continutul unei cozi (scop exclusiv in verificarea 
    implementarii pe parcurs)

Punctaj local:
- punctaj task-uri: 95/100
- punctaj valgrind: 12/20 